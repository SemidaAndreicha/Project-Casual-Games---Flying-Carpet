window.onload = function() {startscreen()};

function startscreen() {
	canvas = document.getElementById("game");
	mouse = utils.captureMouse(canvas);
	drawingSurface = canvas.getContext("2d");
	bimg = document.getElementById("imageTitle");
	NewGameButton = {x:200, y:190, width:570, height:210};
	DescriptionButton = {x:200, y:470, width:570, height:210};
	canvas.height = 735;
	canvas.width = 1000;
	drawingSurface.drawImage(bimg,0,0,canvas.width,canvas.height);
	drawingSurface.font = "bold italic 80px serif";
	drawingSurface.fillStyle="#F59500";
	drawingSurface.fillText("Play", 415, 315);
	drawingSurface.fillText("Description", 300, 600);
	canvas.addEventListener('click', titleClick);
	canvas.addEventListener('mousedown', changeTitleFont);
	canvas.addEventListener('mouseup', fixTitleFont);
};

function changeTitleFont() {
	if (utils.containsPoint(NewGameButton, mouse.x, mouse.y)) { 
		drawingSurface.fillStyle="#000000";
		drawingSurface.fillText("Play", 415, 315);
	} else if (utils.containsPoint(DescriptionButton, mouse.x, mouse.y)) {
		drawingSurface.fillStyle="#000000";
		drawingSurface.fillText("Description", 300, 600);
	};		
};

function fixTitleFont() {
	drawingSurface.fillStyle="#F59500";
	drawingSurface.fillText("Play", 415, 315);
	drawingSurface.fillText("Description", 300, 600);
};

 function titleClick() {
	if (utils.containsPoint(NewGameButton, mouse.x, mouse.y)) { 
		drawingSurface.clearRect(0, 0, canvas.width, canvas.height);
		canvas.removeEventListener('click', titleClick);
		canvas.removeEventListener('mousedown', changeTitleFont);
		canvas.removeEventListener('mouseup', fixTitleFont);
		startgame();
	} else if (utils.containsPoint(DescriptionButton, mouse.x, mouse.y)) {
		drawingSurface.clearRect(0, 0, canvas.width, canvas.height);
		canvas.removeEventListener('click', titleClick);
		canvas.removeEventListener('mousedown', changeTitleFont);
		canvas.removeEventListener('mouseup', fixTitleFont);
		descriptionScreen();
	};
};

function descriptionScreen() {
	var image = document.getElementById("imageDescription");
	Descripttext = [
	"This is your character. Use the arrow keys to move.", 
	"Hit the right answer to the question and get a coin.", 
	"Avoid the lightning or you might lose a life!", 
	"Touch the moving heart to restore a lost life.",
	"Here you see your total points and progress per level.",
	"This is how much lives you have remaining."
	];
	Descriptx = [500, 375, 275, 275, 25, 500];
	Descripty = [525, 475, 300, 300, 650, 700];
	NextButtonCount = 0;
	DescriptionBackButton = {x:20, y:170, width:290, height:90};
	DescriptionNextButton = {x:20, y:365, width:290, height:90};
	drawingSurface.drawImage(image,0,0,canvas.width,canvas.height);
	drawingSurface.font = "bold italic 40px serif";
	drawingSurface.fillStyle="#F59500";
	drawingSurface.fillText("Main Menu", 70, 225);
	drawingSurface.fillText("Next Tip", 100, 425);
	drawingSurface.font = "30px Impact, Charcoal, sans-serif";
	drawingSurface.fillStyle="#FFFFFF"
	drawingSurface.strokeStyle="#000000"
	drawingSurface.fillText(Descripttext[NextButtonCount], Descriptx[NextButtonCount], Descripty[NextButtonCount], 500);
	drawingSurface.strokeText(Descripttext[NextButtonCount], Descriptx[NextButtonCount], Descripty[NextButtonCount], 500);
	canvas.addEventListener('click', descriptionClick);
	canvas.addEventListener('mousedown', changeDescriptFont);
	canvas.addEventListener('mouseup', fixDescriptFont);
};

function changeDescriptFont() {
	if (utils.containsPoint(DescriptionBackButton, mouse.x, mouse.y)) { 
		drawingSurface.font = "bold italic 40px serif";
		drawingSurface.fillStyle="#000000";
		drawingSurface.fillText("Main Menu", 70, 225);
	} else if (utils.containsPoint(DescriptionNextButton, mouse.x, mouse.y)) {
		drawingSurface.font = "bold italic 40px serif";
		drawingSurface.fillStyle="#000000";
		drawingSurface.fillText("Next Tip", 100, 425);
	};		
};

function fixDescriptFont() {
	drawingSurface.font = "bold italic 40px serif";
	drawingSurface.fillStyle="#F59500";
	drawingSurface.fillText("Main Menu", 70, 225);
	drawingSurface.fillText("Next Tip", 100, 425);
};

 function descriptionClick() {	
	if (utils.containsPoint(DescriptionBackButton, mouse.x, mouse.y)) {
		drawingSurface.clearRect(0, 0, canvas.width, canvas.height); 
		canvas.removeEventListener('click', descriptionClick);
		canvas.removeEventListener('mousedown', changeDescriptFont);
		canvas.removeEventListener('mouseup', fixDescriptFont);
		startscreen();
	};
	if (utils.containsPoint(DescriptionNextButton, mouse.x, mouse.y)) {
		drawingSurface.clearRect(0, 0, canvas.width, canvas.height);
		NextButtonCount++;
		if (NextButtonCount == 6) {
			NextButtonCount = 0;
		}
		var image = document.getElementById("imageDescription");
		drawingSurface.drawImage(image,0,0,canvas.width,canvas.height);
		drawingSurface.font = "bold italic 40px serif";
		drawingSurface.fillStyle="#F59500";
		drawingSurface.fillText("Main Menu", 70, 225);
		drawingSurface.fillText("Next Tip", 100, 425);
		drawingSurface.font = "30px Impact, Charcoal, sans-serif";
		drawingSurface.fillStyle="#FFFFFF"
		drawingSurface.fillText(Descripttext[NextButtonCount], Descriptx[NextButtonCount], Descripty[NextButtonCount], 500);
		drawingSurface.strokeText(Descripttext[NextButtonCount], Descriptx[NextButtonCount], Descripty[NextButtonCount], 500);
	};
};
