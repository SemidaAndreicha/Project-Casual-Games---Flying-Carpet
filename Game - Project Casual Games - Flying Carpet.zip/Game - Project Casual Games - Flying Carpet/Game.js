//--- The sprite object

function startgame(){
var spriteObject =
{
  image: "",
  sourceX: 0,
  sourceY: 0,
  sourceWidth: 100,
  sourceHeight: 100,
  width: 100,
  height: 100,
  x: 0,
  y: 0,
  vx: 0,
  vy: 0,
  visible: true,
  
  //Physics properties
  accelerationX: 0, 
  accelerationY: 0.05, 
  speedLimit: 5, 
  friction: 0.96,
  bounce: -0.7,
  gravity: 0.3,
    
  //Platform game properties   
  isOnGround: undefined,
  jumpForce: -10,

  //Getters
  centerX: function()
  {
    return this.x + (this.width / 2);
  },
  centerY: function()
  {
    return this.y + (this.height / 2);
  },
  halfWidth: function()
  {
    return this.width / 2;
  },
  halfHeight: function()
  {
    return this.height / 2;
  }
};

//--- The main program

// Variables for level and equation
var counter = 1;
var level = 1;
// Place for raindrop with the right answer
var place_for_answer = Math.floor(Math.random() * 3);
// Variable for amount of lives
var amountLives = 3;
// Allow programme reacte when the enter is pressed
var enterAllow = false;
var charSpriteX = 0;
var charSpriteY = 0;
// for additional pulsing heart
var place_addLife = Math.floor(Math.random( ) * (9 - 3 + 1)) + 3;
var angle = 0;

//Object arrays
var sprites = [];
var assetsToLoad = [];
var assetsLoaded = 0;

// Randomization of equations
var Order = [];
for (i = 0; i < 10; i++) {
	var Permutation = Math.floor(Math.random() * 10 + 1);
	if (Order.indexOf(Permutation) == -1){
	Order.push(Permutation);
	}
	else if (Order.length < 10){
	i--
	}
}

var foreground = Object.create(spriteObject);
foreground.sourceY = 0;
foreground.sourceX = 0;
foreground.sourceWidth = 2048;
foreground.sourceHeight = 579;
foreground.width = 5000;
foreground.height = 735;
foreground.x = 0;
foreground.y = 0;
sprites.push(foreground);

var image = new Image();
image.addEventListener("load", loadHandler, false);
image.src = "./Images/background1.jpg";
assetsToLoad.push(image);

//Create the character
var character = Object.create(spriteObject);
character.x = 150;
character.y = 250;
character.sourceHeight = 35;
character.sourceWidth = 51;
character.width = 138;
character.height = 100;
sprites.push(character);

var image = new Image();
image.addEventListener("load", loadHandler, false);
image.src = "./Images/char2.png";                  
assetsToLoad.push(image);

//Create the cloud 
var cloud = Object.create(spriteObject);
cloud.sourceX = 100;                                      //
cloud.x = 835;
cloud.y = 0;
cloud.width = 400;
cloud.height = 200;
sprites.push(cloud);

//Create the raindrop (answer)
var answer = Object.create(spriteObject);
answer.sourceX = 200;                                    //
answer.x = cloud.x + 150;
answer.y = 200 + (199 * place_for_answer);
sprites.push(answer);

//Create two wrong aswers
var raindrop1 = Object.create(spriteObject);
raindrop1.sourceX = 300;                                  //
raindrop1.x = cloud.x + 150;
var place1raindrop = 0;
while (place1raindrop == place_for_answer) {
	place1raindrop++;
} 
raindrop1.y = 200 + (199 * place1raindrop);
sprites.push(raindrop1);

var raindrop2 = Object.create(spriteObject);
raindrop2.sourceX = 400;                                    //
raindrop2.x = cloud.x + 150;
var k = 0;
while (k == place_for_answer || k == place1raindrop) {
	k++;
} 
raindrop2.y =  200 + (199 * k);
sprites.push(raindrop2);

//Create hearts
var heart1 = Object.create(spriteObject);
heart1.sourceX = 500;                                        //
heart1.x = 950;
heart1.y = 685;
heart1.width = 50;
heart1.height = 50;
sprites.push(heart1);

var heart2 = Object.create(spriteObject);
heart2.sourceX = 500;                                         //
heart2.x = 880;
heart2.y = 685;
heart2.width = 50;
heart2.height = 50;
sprites.push(heart2);

var heart3 = Object.create(spriteObject);
heart3.sourceX = 500;                                          //
heart3.x = 810;
heart3.y = 685;
heart3.width = 50;
heart3.height = 50;
sprites.push(heart3);

var addLife = Object.create(spriteObject);
addLife.sourceX = 500;                                          
addLife.x = 825;
addLife.y = 250;
addLife.width = 50;
addLife.height = 50;
addLife.visible = false;
sprites.push(addLife);

// Load the image for described stuff from the spritesheet (cloud, raindrop etc.)
for (i = 0; i < 8; i++) {
	var image = new Image();
	image.addEventListener("load", loadHandler, false);
	// level * 10 - 10 means it will be 1-10 for level 1, 11-20 level 2, 21-30 level 3.
	// Order[(counter) % 10] will take a unique number from the randomization array.
	image.src = "./Images/set" + (level * 10 + Order[(counter) % 10] - 10) + ".png";                 
	assetsToLoad.push(image);
}

//Create the right/wrong answer image
var rightanswer = Object.create(spriteObject);
rightanswer.sourceX = 0;
rightanswer.sourceY = 100;
rightanswer.x = character.x;
rightanswer.y = character.y + 100;
rightanswer.width = 100;
rightanswer.height = 100;
rightanswer.visible = false;
sprites.push(rightanswer);

var wronganswer = Object.create(spriteObject);
wronganswer.sourceX = 600;
wronganswer.sourceY = 100;    
wronganswer.x = character.x;
wronganswer.y = character.y + 100;
wronganswer.width = 100;
wronganswer.height = 100;
wronganswer.visible = false;
sprites.push(wronganswer);

//Create the points counter
var points = Object.create(spriteObject);
points.sourceX = 0;
points.sourceY = 0;
points.x = 0;
points.y = 660;
points.width = 75;
points.height = 75;
points.visible = true;
sprites.push(points);

var coinstack = Object.create(spriteObject);
coinstack.sourceX = 100;
coinstack.sourceY = 100;
coinstack.x = 75;
coinstack.y = 660;
coinstack.width = 75;
coinstack.height = 75;
coinstack.visible = true;
sprites.push(coinstack);

for (i = 0; i < 4; i++) {
	var image = new Image();
	image.addEventListener("load", loadHandler, false);
	image.src = "./Images/Points.png";
	assetsToLoad.push(image);
}

//Create the inner meter and center
//it above the monster
var innerMeter = Object.create(spriteObject);
innerMeter.sourceY = 142;
innerMeter.sourceWidth = 128;
innerMeter.sourceHeight = 14;
innerMeter.width = 128;
innerMeter.height = 14;
innerMeter.x = character.x + 15;
innerMeter.y = character.y - 32;
sprites.push(innerMeter);

//Create the outer meter and position it
//over the inner meter
var outerMeter = Object.create(spriteObject);
outerMeter.sourceY = 128;
outerMeter.sourceWidth = 128;
outerMeter.sourceHeight = 14;
outerMeter.width = 128;
outerMeter.height = 14;
outerMeter.x = innerMeter.x;
outerMeter.y = innerMeter.y;
sprites.push(outerMeter);

//Load the image
for (i = 0; i < 2; i++){
	var pic = new Image();
	pic.addEventListener("load", loadHandler, false);
	pic.src = "./Images/collisionTileSheet.png";
	assetsToLoad.push(pic);
}

//Create lightning
var lightning = Object.create(spriteObject);
lightning.sourceWidth = 135;
lightning.sourceHeight = 586;  
lightning.width = 30;                                             //change the size of lightning
lightning.height = canvas.height;
lightning.x = Math.floor(Math.random() * cloud.x);
lightning.visible = false;
sprites.push(lightning);
		
var image = new Image();
image.addEventListener("load", loadHandler, false);
image.src = "./Images/lightning.png";                  
assetsToLoad.push(image);

// Create the message when the level is completed

var mesComplete = Object.create(spriteObject);
mesComplete.y = 200;
mesComplete.width = 1000;
mesComplete.height = 300;
mesComplete.sourceWidth = 600;
mesComplete.sourceHeight = 200;
mesComplete.visible = false;
sprites.push(mesComplete);

var image = new Image();
image.addEventListener("load", loadHandler, false);
image.src = "./Images/mesComplete.png";                            //message    level is completed                       
assetsToLoad.push(image);

//create the message when the player won

var mesWon = Object.create(spriteObject);
mesWon.y = 200;
mesWon.width = 1000;
mesWon.height = 300;
mesWon.sourceWidth = 600;
mesWon.sourceHeight = 200;
mesWon.visible = false;
sprites.push(mesWon);
			
var image = new Image();
image.addEventListener("load", loadHandler, false);
image.src = "./Images/mesWon.png";                             //message    you won                    
assetsToLoad.push(image);

//create the message when the player died
var mesDied = Object.create(spriteObject);
mesDied.y = 200;
mesDied.width = 1000;
mesDied.height = 300;
mesDied.sourceWidth = 600;
mesDied.sourceHeight = 200;
mesDied.visible = false;
sprites.push(mesDied);
		
var image = new Image();
image.addEventListener("load", loadHandler, false);
image.src = "./Images/mesDied.png";                             //message    you die                 
assetsToLoad.push(image);

//Create mathOmeter which shows how far is the end of the level
var mathOmeter = Object.create(spriteObject);
mathOmeter.x = 150;
mathOmeter.y = 685;
mathOmeter.width = 200;
mathOmeter.height = 50;
sprites.push(mathOmeter);

var image = new Image();
image.addEventListener("load", loadHandler, false);
image.src = "./Images/mathOmeter.png";                                              
assetsToLoad.push(image);

//Game states
var gameState = "LOADING";

//Arrow key codes
var UP = 38;
var DOWN = 40;
var RIGHT = 39;
var LEFT = 37;
var ENTER = 13;

//Directions
var moveUp = false;
var moveDown = false;
var moveRight = false;
var moveLeft = false;

//Add keyboard listeners
window.addEventListener("keydown", function(event)
{
  switch(event.keyCode)
  {
    case UP:
	    moveUp = true;
	    break;
	  
	  case DOWN:
	    moveDown = true;
	    break;
	    
	  case LEFT:
	    moveLeft = true;
	    break;  
	    
	  case RIGHT:
	    moveRight = true;
	    break; 
		
	  case ENTER:
		if (enterAllow){
			// Go to the title screen if you're finished
			if (amountLives <= 0 || level == 3) {
				cancelAnimationFrame(requestID);
				drawingSurface.clearRect(0, 0, canvas.width, canvas.height);
				enterAllow = false;
				startscreen();
			}
			// If level less than 3, change the level
		    else if (level < 3) {
				level++;
				foreground.image.src = "./Images/background" + level + ".jpg";
				foreground.sourceX = 0;
				foreground.x = 0;
				//Calculate the places (X, Y) for raindrops, cloud, answer for the first equation of the new level
				place_for_answer = Math.floor(Math.random() * 3);
				cloud.sourceX = 100;                                      
				cloud.x = 835;
				cloud.y = 0;
				cloud.image.src = "./Images/set" + (level * 10 + Order[(counter) % 10] - 10) + ".png"
				answer.sourceX = 200;                                    
				answer.x = cloud.x + 150;
				answer.y = 200 + (199 * place_for_answer);
				answer.image.src = "./Images/set" + (level * 10 + Order[(counter) % 10] - 10) + ".png"
				raindrop1.sourceX = 300;                                  
				raindrop1.x = cloud.x + 150;
				place1raindrop = 0;
				place_addLife = Math.floor(Math.random( ) * (9 - 3 + 1)) + 3 + (level - 1) * 10;
				addLife.x = 825;
				while (place1raindrop == place_for_answer) {
					place1raindrop++;
				} 
				raindrop1.y = 200 + (199 * place1raindrop);
				raindrop1.image.src = "./Images/set" + (level * 10 + Order[(counter) % 10] - 10) + ".png"
				raindrop2.sourceX = 400;                                    
				raindrop2.x = cloud.x + 150;
				var k = 0;
				while (k == place_for_answer || k == place1raindrop) {
					k++;
				} 
				raindrop2.y =  200 + (199 * k);
				raindrop2.image.src = "./Images/set" + (level * 10 + Order[(counter) % 10] - 10) + ".png"
				// Change the coins to the ones for the next level
				coinstack.sourceX += 200;
				rightanswer.sourceX += 200;
				// Make meter above the character full (full life)
				innerMeter.sourceWidth = 128;
				innerMeter.width = 128;
				// Return mathOmeter to the lowest state (when the end of the level is as far as possible)
				mathOmeter.sourceX = 0;
				// Make the message invisible but stuff for playing (character, clouds etc.) visible
				mesComplete.visible = false;
				character.visible = true;
				cloud.visible = true;
				answer.visible = true;
				raindrop1.visible = true;
				raindrop2.visible = true;
				heart1.visible = true;
				heart2.visible = true;
				heart3.visible = true;
				points.visible = true;
				coinstack.visible = true;
				innerMeter.visible = true;
				outerMeter.visible = true;
				mathOmeter.visible = true;
				// Make impossible to react on enter press during the game
				enterAllow = false;
				gameState = "PLAYING";
				amountLives = 3;
			}
		}
		break;
  }
}, false);

window.addEventListener("keyup", function(event)
{
  switch(event.keyCode)
  {
    case UP:
	    moveUp = false;
	    break;
	  
	  case DOWN:
	    moveDown = false;
	    break;
	    
	  case LEFT:
	    moveLeft = false;
	    break;  
	    
	  case RIGHT:
	    moveRight = false;
	    break; 
	
	  case ENTER:
		enterAllow = false;
		break;
  }
}, false);

update();

function update()
{ 
  //The animation loop
  requestID = requestAnimationFrame(update, canvas);
  if (!mesDied.visible && !mesComplete.visible && !mesWon.visible) {
	foreground.x = foreground.x - 0.5;
  }
  
  //Change what the game is doing based on the game state
  switch(gameState)
  {
    case "LOADING":
      console.log("loading...");
      break;
    
    case "PLAYING":
      playGame();
      break;
	  
	case "ENDGAME":                     //When you win
	  showEndGame();
	  break;
	
	case "NEWGAME":                       // When you died
	  showNewGame();
	  break;
	  
	case "NEWLEVEL":                   //When the level is passed
	  showNewLevel();
      break;
  }
  //checks wheter there was the last equation and if it so wheter it is the last level (you won or just change the level)
  if ((counter > 10 * level) && amountLives > 0){
		enterAllow = true;
		if (level < 3){
			gameState = "NEWLEVEL";
		}
		else {
			gameState = "ENDGAME";
		}
  }
  //checks if character is still alive
  if (amountLives < 1) {
		enterAllow = true;
		gameState = "NEWGAME";
	}
  //Render the game
  render();
}

//connects the sprites' images with the function that loads the images
function loadHandler()
{
  assetsLoaded++;
  if(assetsLoaded == assetsToLoad.length)
  {
    for(var i = 0; i < assetsToLoad.length; i++)
    {
      sprites[i].image = assetsToLoad[i];
    }
    gameState = "PLAYING";
  }
}

function showEndGame() {
    //make everything invisible except the message and allow the enter key press to work
	enterAllow = true;
	mesWon.visible = true;
	character.visible = false;
	cloud.visible = false;
	answer.visible = false;
	raindrop1.visible = false;
	raindrop2.visible = false;
	heart1.visible = false;
	heart2.visible = false;
	heart3.visible = false;
	rightanswer.visible = false;
	wronganswer.visible = false;
	points.visible = false;
	coinstack.visible = false;
	innerMeter.visible = false;
	outerMeter.visible = false;
	lightning.visible = false;
	mathOmeter.visible = false;
	addLife.visible = false;
}

function showNewGame() {
    //make everything invisible except the message and allow the enter key press to work
	enterAllow = true;
	mesDied.visible = true;
	character.visible = false;
	cloud.visible = false;
	answer.visible = false;
	raindrop1.visible = false;
	raindrop2.visible = false;
	heart1.visible = false;
	heart2.visible = false;
	heart3.visible = false;
	rightanswer.visible = false;
	wronganswer.visible = false;
	points.visible = false;
	coinstack.visible = false;
    innerMeter.visible = false;
	outerMeter.visible = false;
	lightning.visible = false;
	mathOmeter.visible = false;
	addLife.visible = false;
}

function showNewLevel() {
	//make everything invisible except the message and allows the enter key to be pressed
	enterAllow = true;
	mesComplete.visible = true;
	character.visible = false;
	cloud.visible = false;
	answer.visible = false;
	raindrop1.visible = false;
	raindrop2.visible = false;
	heart1.visible = false;
	heart2.visible = false;
	heart3.visible = false;
	rightanswer.visible = false;
	wronganswer.visible = false;
	points.visible = false;
	coinstack.visible = false;
	innerMeter.visible = false;
	outerMeter.visible = false;
	lightning.visible = false;
	mathOmeter.visible = false;
	addLife.visible = false;
}

function playGame()
{ 
  //Set the character's acceleration if the keys are being pressed
  //Up
  if(moveUp && !moveDown)
  {
    character.accelerationY = -0.2;
    character.friction = 1;
  }
  //Down
  if(moveDown && !moveUp)
  {
    character.accelerationY = 0.2;
    character.friction = 1;
  }
  //Left
  if(moveLeft && !moveRight)
  {
    character.accelerationX = -0.2;
    character.friction = 1;
  }
  //Right
  if(moveRight && !moveLeft)
  {
    character.accelerationX = 0.2;
    character.friction = 1;
  }
  
  //Set the character's acceleration and friction to zero if none of the keys are being pressed
  if(!moveUp && !moveDown)
  {
    character.accelerationY = 0.03; // actually, this is a gravity
  }
  if(!moveLeft && !moveRight)
  {
    character.accelerationX = 0; 
  }
  if(!moveUp && !moveDown && !moveLeft && !moveRight)
  {
    character.friction = 0.96; 
  }
  	
  //Apply the acceleration
  character.vx += character.accelerationX; 
  character.vy += character.accelerationY;
  
  //Apply friction
  character.vx *= character.friction; 
  character.vy *= character.friction;

  //Move the character
  character.x += character.vx;
  character.y += character.vy;
  
  //Bounce the objects
  blockRectangle(character, cloud, true);
  
  //Bounce off the screen edges
  //Left
  if(character.x < 0)
  {
    character.vx *= character.bounce; // inverts speed
    character.x = 0;
  }
  //Up
  if(character.y < 50)
  {
    character.vy *= character.bounce;
    character.y = 50;
  }
  //Right
  if(character.x + character.width > canvas.width)
  {
    character.vx *= character.bounce;
    character.x = canvas.width - character.width;
  }
  //Down
  if(character.y + character.height > canvas.height)
  {
    character.vy *= character.bounce;
    character.y = canvas.height - character.height;
  }
  
    //place pulsing heart on the screen if it is a time  
  if (place_addLife == counter){
	addLife.visible = true;
	addLife.x -= 2;
	addLife.y = 250 + Math.sin(angle) * 50;
	addLife.height = addLife.width = 50 + Math.sin(angle) * 15; 
	angle += 0.05; 
  }
  else{
	addLife.visible = false;
  }
  //check if chatacter grab the heart
  if (utils.intersects(addLife, character) && addLife.visible == true){
	addLife.visible = false;
	place_addLife = 0;
	if (amountLives < 3){
		amountLives ++;
		sprites[6 + amountLives - 1].visible = true;
	}
  }
  
  //change the cloud posion if it is still on the screen
  if (cloud.x > -400 && counter <= level * 10 && amountLives > 0){ 
	cloud.x += -1;
	answer.x += -1;
	//change raindrop position
	raindrop1.x += -1;
	raindrop2.x += -1;
	//change meter position to be above the character
	innerMeter.x = character.x + 15;
	innerMeter.y = character.y - 32;
	outerMeter.x = innerMeter.x;
	outerMeter.y = innerMeter.y;
	//make character moves (carpet, hear)
    character.sourceX = 52 * charSpriteX;
	if (cloud.x % 7 == 0){ //every 7 pixels
			if(charSpriteX < 3){
				charSpriteX++;
			}
			else{
				charSpriteX = 0;
			}
		}

//Make lightning
	if (cloud.x % 100 == 25){
		lightning.visible = true;
	}
//delete lightning (and the right/wrong hit notification too)
	if (cloud.x % 100 == 0){
		lightning.visible = false;
		lightning.x = Math.floor(Math.random() * cloud.x);
		rightanswer.visible = false;
		wronganswer.visible = false;
	}
//if lightning and character intersects, change character`s meter
	if(utils.intersects(lightning, character) && lightning.visible == true){
		if(innerMeter.width > 0)
		{
		  innerMeter.width--;
		  innerMeter.sourceWidth--;
		}
	}
//If meter is empty, change amount of lives
	if(innerMeter.width < 1){
		if (amountLives > 0){
			amountLives--;
			innerMeter.sourceWidth = 128;
			innerMeter.width = 128;
			sprites[6 + amountLives].visible = false;			
        }		
	}
  }
//If character cross one of raindrops
  if ((utils.intersects(character, answer) || utils.intersects(character, raindrop1) || utils.intersects(character, raindrop2)) && (amountLives > 0)) {
	mathOmeter.sourceX += 100;
	if (utils.intersects(character, answer)){
		rightanswer.x = answer.x;
		rightanswer.y = answer.y;
		rightanswer.visible = true;
		points.sourceX += 100;
	}
	//If wrong answer. delete 1 life
	if (utils.intersects(character, raindrop1)){
		amountLives += -1;
		sprites[6 + amountLives].visible = false;
		wronganswer.x = raindrop1.x;
		wronganswer.y = raindrop1.y;
		wronganswer.visible = true; 
	}
	if (utils.intersects(character, raindrop2)){
		amountLives += -1;
		sprites[6 + amountLives].visible = false;
 		wronganswer.x = raindrop2.x;
		wronganswer.y = raindrop2.y;
		wronganswer.visible = true; 
	}
	//Delete the cloud + raindrops and draw the new ones
	if (amountLives > 0 && counter <= level * 10){
		counter ++;
		place_for_answer = Math.floor(Math.random() * 3);
		cloud.sourceX = 100;                                      
		cloud.x = 835;
		cloud.y = 0;
		cloud.image.src = "./Images/set" + (level * 10 + Order[(counter) % 10] - 10) + ".png"
		answer.sourceX = 200;                                    
		answer.x = cloud.x + 150;
		answer.y = 200 + (199 * place_for_answer);
		answer.image.src = "./Images/set" + (level * 10 + Order[(counter) % 10] - 10) + ".png"
		raindrop1.sourceX = 300;                                  
		raindrop1.x = cloud.x + 150;
		place1raindrop = 0;
		while (place1raindrop == place_for_answer) {
			place1raindrop++;
		} 
		raindrop1.y = 200 + (199 * place1raindrop);
		raindrop1.image.src = "./Images/set" + (level * 10 + Order[(counter) % 10] - 10) + ".png"
		raindrop2.sourceX = 400;                                    
		raindrop2.x = cloud.x + 150;
		var k = 0;
		while (k == place_for_answer || k == place1raindrop) {
			k++;
		} 
		raindrop2.y =  200 + (199 * k);
		raindrop2.image.src = "./Images/set" + (level * 10 + Order[(counter) % 10] - 10) + ".png"
	}
  }
}

function blockRectangle(r1, r2, bounce)
{
  //Set bounce to a default value of false if it's not specified
  if(typeof bounce === "undefined")
  {
    bounce = false;
  }
  
  //A variable to tell us which side the 
  //collision is occurring on
  var collisionSide = "";
  
  //Calculate the distance vector
  var vx = r1.centerX() - r2.centerX();
  var vy = r1.centerY() - r2.centerY();
  
  //Figure out the combined half-widths and half-heights
  var combinedHalfWidths = r1.halfWidth() + r2.halfWidth();
  var combinedHalfHeights = r1.halfHeight() + r2.halfHeight();
    
  //Check whether vx is less than the combined half widths 
  if(Math.abs(vx) < combinedHalfWidths) 
  {
    //A collision might be occurring! 
    //Check whether vy is less than the combined half heights 
    if(Math.abs(vy) < combinedHalfHeights)
    {
      //A collision has occurred! This is good! 
      //Find out the size of the overlap on both the X and Y axes
      var overlapX = combinedHalfWidths - Math.abs(vx);
      var overlapY = combinedHalfHeights - Math.abs(vy);
        
      //The collision has occurred on the axis with the
      //*smallest* amount of overlap. Let's figure out which
      //axis that is
        
      if(overlapX >= overlapY)
      {
        //The collision is happening on the X axis 
        //But on which side? vy can tell us
        if(vy > 0)
        {
          collisionSide = "top";
            
          //Move the rectangle out of the collision
          r1.y = r1.y + overlapY;
        }
        else 
        {
          collisionSide = "bottom";
          
          //Move the rectangle out of the collision
          r1.y = r1.y - overlapY;
        }
    
        //Bounce
        if(bounce)
        {
          r1.vy *= -1;
        }
      } 
      else 
      {
        //The collision is happening on the Y axis 
        //But on which side? vx can tell us
        if(vx > 0)
        {
          collisionSide = "left";
            
          //Move the rectangle out of the collision
          r1.x = r1.x + overlapX;
        }
        else 
        {
          collisionSide = "right";
            
          //Move the rectangle out of the collision
          r1.x = r1.x - overlapX;
        }
        
        //Bounce
        if(bounce)
        {
          r1.vx *= -1;
			    
        }
      } 
    }
    else 
    {
      //No collision
      collisionSide = "none";
    }
  } 
  else 
  {
    //No collision
    collisionSide = "none";
  }
  
  return collisionSide;
}

function render()
{ 
  drawingSurface.clearRect(0, 0, canvas.width, canvas.height);
  
  //Display the sprites
  if(sprites.length !== 0)
  {
	  for(var i = 0; i < sprites.length; i++)
	  {
	     var sprite = sprites[i];
	     if(sprite.visible)
	     {
		     drawingSurface.drawImage
		     (
		       sprite.image, 
		       sprite.sourceX, sprite.sourceY, 
		       sprite.sourceWidth, sprite.sourceHeight,
		       Math.floor(sprite.x), Math.floor(sprite.y), 
		       sprite.width, sprite.height
		     ); 
	     }
	  }
  }
}
}